# Release Security Audit — Preloop 0.17.1

**Verdict: fail.** The severity gate failed after waiver application because two database-matched findings meet the platform CVSS >= 9.0 threshold — Authlib 1.8.0 (GHSA-6v38-4h7w-rj9h, CVSS 9.1) and litellm 1.101.0 (GHSA-7hp6-4w63-5g45, CVSS 9.9) — and no waiver was delivered.

Run `2026-11-04T02:22:21Z` · Product **Preloop 0.17.1** · Regime profile **CRA** · Scope: the three delivered SBOMs (artifact-only run; no `project_path`, no repository).

## BOX 1 — What we checked

**Inputs actually delivered.** Three CycloneDX 1.6 SBOMs — `sbom/backend.cdx.json` (178 components), `sbom/frontend.cdx.json` (376 components, 27 nested) and `sbom/cli.cdx.json` (22 components) — plus `vex/preloop-frontend.openvex.json` (OpenVEX 0.2.0, 25 statements) and `build/SHA256SUMS` (17 release artefact digests). The three SBOMs and the VEX file match their `SHA256SUMS` entries byte for byte. No trigger payload was rendered, so no gate policy, waivers, project_path, repository or previous result was delivered. No license policy file was delivered.

**Screening coverage, from the per-source matrix:**

- osv_purl: screened 576 of 576 components (database match; control passed)
- osv_git: screened 251 of 576 components (database match; control passed)
- nvd_cpe: screened 0 of 576 components (labeled heuristic; control passed)
- osv_distro: screened 0 of 576 components (labeled heuristic; control passed)

**Upstream resolution (osv_git enrichment):** resolved via registry **0**; via already-present `vcs_url` **251** (333 components carried a `vcs_url`, 82 had no matching upstream tag); unresolved **325** (82 tag-unresolved plus 243 without `vcs_url`, for which the one batched registry lookup resolved none; both the Arduino index and the PlatformIO registry reported `ok`).

This run demonstrates the pipeline; it is not yet a complete CRA gap review unless the gap-register phase ran AND private product repositories were in scope. Neither held here: no repository was attached, so the gap-register phase did not run, and no private product repositories were in scope.

## BOX 2 — What we did NOT check

- **Components no source could screen: 0.** All 576 components were screened by `osv_purl`. `osv_git` did not screen 325 of them and the two heuristics screened none, but no component was unscreened by every method, so `source_matrix.screened_by_no_source` is 0.
- **Blind sources: none.** All four negative controls returned known-vulnerable results (django 2.0.0 → 35 advisories; curl commit 6fa1d81 → CVE-2023-38545; NVD haxx:curl:7.50.0 → 77 CVEs; distro curl 7.50.0 → 1,711 entries).
- **Skipped cross-checks:** component-level build manifest (absent — `SHA256SUMS` is an artefact checksum list, not a package list); cross-format normalization (only CycloneDX 1.6 was delivered, for three different sub-products); previous-run drift (no baseline); license-policy flags (no policy file).
- **Not checkable from a repository, because no repository was attached (entire PHASE 3.5):** CVD policy, public security contact, declared support window, Article 14 runbooks, update/signed-OTA evidence, secrets hygiene and git-history pickaxe, default credentials and open provisioning, repository hygiene, key-management pointers, in-repo CI secret scanning, in-repo CI SBOM job, and debug-build leakage. None of these can be established from an SBOM and VEX alone.

## Reportable under CRA Article 14?

**Reportable under CRA Article 14? No. Not legal advice.**

The CISA KEV catalogue released `2026-11-03T20:00:24.8741Z` (1,767 entries) contains no entry matching any of the 71 findings or their aliases; every screening source completed with a passing control, and no vendor advisory marked a matched issue as actively exploited. There are therefore no Article 14 candidates on this evidence. Preloop does not file anything and has no connection to the ENISA single reporting platform; any submission is the manufacturer’s, made outside this tool.

## VEX suppressions

25 findings were suppressed by the delivered OpenVEX document before the gate. None would have failed the gate (all CVSS below 9.0, none KEV-listed), so `vuln_scan.gate.vex_suppressed` is empty; they are listed here because a suppression not on the cover did not happen.

| Finding | CVE | Statement id | Justification (verbatim) | Gate consequence |
|---|---|---|---|---|
| GHSA-2mjp-6q6p-2qxm (undici-types 7.16.0) | CVE-2026-1525 | `https://preloop.ai/vex/preloop-frontend-0.16.0-1#statement-0` | `vulnerable_code_not_present` | none — CVSS 6.5, below 9.0 |
| GHSA-vrm6-8vpv-qv8q (undici-types 7.16.0) | CVE-2026-1526 | `https://preloop.ai/vex/preloop-frontend-0.16.0-1#statement-1` | `vulnerable_code_not_present` | none — CVSS 7.5, below 9.0 |
| GHSA-4992-7rv2-5pvq (undici-types 7.16.0) | CVE-2026-1527 | `https://preloop.ai/vex/preloop-frontend-0.16.0-1#statement-2` | `vulnerable_code_not_present` | none — CVSS 4.6, below 9.0 |
| GHSA-f269-vfmq-vjvj (undici-types 7.16.0) | CVE-2026-1528 | `https://preloop.ai/vex/preloop-frontend-0.16.0-1#statement-3` | `vulnerable_code_not_present` | none — CVSS 7.5, below 9.0 |
| GHSA-v9p9-hfj2-hcw8 (undici-types 7.16.0) | CVE-2026-2229 | `https://preloop.ai/vex/preloop-frontend-0.16.0-1#statement-4` | `vulnerable_code_not_present` | none — CVSS 7.5, below 9.0 |
| GHSA-35p6-xmwp-9g52 (undici-types 7.16.0) | CVE-2026-6733 | `https://preloop.ai/vex/preloop-frontend-0.16.0-1#statement-5` | `vulnerable_code_not_present` | none — CVSS 3.7, below 9.0 |
| GHSA-pr7r-676h-xcf6 (undici-types 7.16.0) | CVE-2026-9678 | `https://preloop.ai/vex/preloop-frontend-0.16.0-1#statement-6` | `vulnerable_code_not_present` | none — CVSS 5.9, below 9.0 |
| GHSA-p88m-4jfj-68fv (undici-types 7.16.0) | CVE-2026-9679 | `https://preloop.ai/vex/preloop-frontend-0.16.0-1#statement-7` | `vulnerable_code_not_present` | none — CVSS 5.9, below 9.0 |
| GHSA-g8m3-5g58-fq7m (undici-types 7.16.0) | CVE-2026-11525 | `https://preloop.ai/vex/preloop-frontend-0.16.0-1#statement-8` | `vulnerable_code_not_present` | none — CVSS 3.7, below 9.0 |
| GHSA-vxpw-j846-p89q (undici-types 7.16.0) | CVE-2026-12151 | `https://preloop.ai/vex/preloop-frontend-0.16.0-1#statement-9` | `vulnerable_code_not_present` | none — CVSS 7.5, below 9.0 |
| GHSA-4cwx-7wf7-3272 (undici-types 7.16.0) | CVE-2026-13697 | `https://preloop.ai/vex/preloop-frontend-0.16.0-1#statement-10` | `vulnerable_code_not_present` | none — CVSS 7.4, below 9.0 |
| GHSA-jr45-8vmc-qm54 (undici-types 7.16.0) | CVE-2026-14643 | `https://preloop.ai/vex/preloop-frontend-0.16.0-1#statement-11` | `vulnerable_code_not_present` | none — CVSS 5.9, below 9.0 |
| GHSA-m8rv-5g2x-5cg5 (undici-types 7.16.0) | CVE-2026-15157 | `https://preloop.ai/vex/preloop-frontend-0.16.0-1#statement-12` | `vulnerable_code_not_present` | none — CVSS 4.2, below 9.0 |
| GHSA-8xcm-r25x-g524 (undici-types 7.16.0) | CVE-2026-16728 | `https://preloop.ai/vex/preloop-frontend-0.16.0-1#statement-13` | `vulnerable_code_not_present` | none — CVSS 4.8, below 9.0 |
| GHSA-v3r7-h72x-cjcm (undici-types 7.16.0) | CVE-2026-16729 | `https://preloop.ai/vex/preloop-frontend-0.16.0-1#statement-14` | `vulnerable_code_not_present` | none — CVSS 4.8, below 9.0 |
| GHSA-pmjh-fq2x-6v4x (undici-types 7.16.0) | CVE-2026-18149 | `https://preloop.ai/vex/preloop-frontend-0.16.0-1#statement-15` | `vulnerable_code_not_present` | none — CVSS 5.9, below 9.0 |
| GHSA-r53p-7pc4-xj5r (undici-types 7.16.0) | CVE-2026-18540 | `https://preloop.ai/vex/preloop-frontend-0.16.0-1#statement-16` | `vulnerable_code_not_present` | none — CVSS 3.7, below 9.0 |
| GHSA-rfgv-xxqx-mfg5 (undici-types 7.16.0) | CVE-2026-19534 | `https://preloop.ai/vex/preloop-frontend-0.16.0-1#statement-17` | `vulnerable_code_not_present` | none — CVSS 7.5, below 9.0 |
| GHSA-g9mf-h72j-4rw9 (undici-types 7.16.0) | CVE-2026-22036 | `https://preloop.ai/vex/preloop-frontend-0.16.0-1#statement-18` | `vulnerable_code_not_present` | none — CVSS 5.9, below 9.0 |
| GHSA-3xpg-4rpp-hhhm (undici-types 7.16.0) | CVE-2026-84890 | `https://preloop.ai/vex/preloop-frontend-0.16.0-1#statement-19` | `vulnerable_code_not_present` | none — CVSS 5.9, below 9.0 |
| GHSA-2jfj-6hjv-fm6j (undici-types 7.16.0) | CVE-2026-84933 | `https://preloop.ai/vex/preloop-frontend-0.16.0-1#statement-20` | `vulnerable_code_not_present` | none — CVSS 6.5, below 9.0 |
| GHSA-2gqq-gqf2-x968 (undici-types 7.16.0) | CVE-2026-84947 | `https://preloop.ai/vex/preloop-frontend-0.16.0-1#statement-21` | `vulnerable_code_not_present` | none — CVSS 3.7, below 9.0 |
| GHSA-8436-99hf-9mmv (undici-types 7.16.0) | CVE-2026-85008 | `https://preloop.ai/vex/preloop-frontend-0.16.0-1#statement-22` | `vulnerable_code_not_present` | none — CVSS 3.7, below 9.0 |
| GHSA-rx4f-c7p8-82vq (undici-types 7.16.0) | CVE-2026-85014 | `https://preloop.ai/vex/preloop-frontend-0.16.0-1#statement-23` | `vulnerable_code_not_present` | none — CVSS 5.9, below 9.0 |
| GHSA-fvqr-27wr-82fm (lodash.camelcase 4.3.0) | CVE-2018-3721 | `https://preloop.ai/vex/preloop-frontend-0.16.0-1#statement-24` | `vulnerable_code_not_in_execute_path` | none — CVSS 6.5, below 9.0 |

The VEX statement `not_affected` assertions are the supplier’s own claim about files it ships; this audit applies them mechanically and does not independently verify the claim that `undici-types` contains no runtime code. Note also that the document id names frontend 0.16.0 while the file is shipped in the 0.17.1 SHA256SUMS; statements were matched by product purl and vulnerability id, not by the document title, and a human should confirm the document was intended for this release.

## Waivers

No waivers were delivered or applied. The run was non-interactive and made no `ask_user` call.

## BOX 3 — What you should do next week

1. Upgrade **Authlib** from 1.8.0 to at least 1.9.1 — 1.9.0 clears the CVSS 9.1 gate failure GHSA-6v38-4h7w-rj9h, and 1.9.1 also clears the remaining Authlib findings GHSA-8m4g-j4wp-wgcg and GHSA-c73q-w75p-j82v.
2. Upgrade **litellm** from 1.101.0 to at least 1.101.3 — GHSA-7hp6-4w63-5g45 is CVSS 9.9 and currently fails the release gate; check the adjacent fixed ranges (1.100.4, 1.102.2, 1.103.1, 1.104.0rc2) when choosing the target.
3. Decide what to do about the **seven undici-types git-range advisories the delivered VEX does not name** (CVE-2026-109383, -109829, -109841, -109924, -109932, -87018, -87029): extend the VEX with a justified statement, or upgrade/remove `undici-types`.
4. Add license identifiers for the **four components with no license at all** (`only@0.0.2`; `github.com/yosuke-furukawa/json5@v0.1.1`; `go.yaml.in/yaml/v3@v3.0.4`; `gopkg.in/yaml.v3@v3.0.1`).
5. Attach the product repositories and run the CRA gap register — CVD policy, security contact, support window, Article 14 runbook, OTA signing, credential hygiene and CI controls are all still unmeasured.
6. Deliver a previous `result.json` next time so drift, new KEV listings and gate transitions can be measured instead of reported as null.

## Drift and NTIA reconciliation

**Drift:** no previous result was delivered. Drift is `null`; no baseline comparison was made, and no “first run with an SBOM” statement can be made because there is no baseline to compare against. This is not evidence that nothing changed.

**NTIA reconciliation:** the NTIA/CRA minimum-elements measurement **passes** (576 components; missing: none), so no reconciliation sentence is required. The overall verdict is fail solely because of the independent severity gate.

---

## 1. What was verified, against which build evidence

| SBOM | Format / spec | Components | Generator | Document timestamp | SHA-256 vs `SHA256SUMS` |
|---|---|---|---|---|---|
| `sbom/backend.cdx.json` | CycloneDX 1.6 | 178 | cyclonedx-py 7.3.1 / cyclonedx-python-lib 11.12.0 | 2026-10-21T10:20:28.439585+00:00 | match |
| `sbom/frontend.cdx.json` | CycloneDX 1.6 | 376 | cyclonedx-npm 4.0.2 / cyclonedx-library 9.5.0 / npm 10.9.9 | 2026-10-21T10:20:52.448Z | match |
| `sbom/cli.cdx.json` | CycloneDX 1.6 | 22 | cyclonedx-gomod v1.9.0 | 2026-10-21T10:21:15Z | match |

**SBOM audit verdict: `pass_with_findings`.** The SBOMs are valid and all NTIA minimum elements are present; the four missing licence entries are recorded as findings rather than a validity failure.

All three documents validate against the official CycloneDX 1.6 JSON schema (draft-07, `jsonschema` 4.26.0) with **0 errors**, **0 duplicate `bom-ref`s** and **0 dangling dependency references**. Every document carries an author, a timestamp and a `dependencies` section; no SPDX document was delivered, so there is no per-format relationship contrast to draw.

**Build cross-check.** `build/SHA256SUMS` holds 17 release artefact digests (wheel, sdist, npm tarball, six platform binaries, installers, compose file, three SBOMs and the VEX). The three SBOM digests and the VEX digest match the manifest. The manifest is not a component/package list, so the SBOM could not be diffed against the build’s component inventory; `coverage.unmatched_vs_build` is `null` for that reason.

**Tools and snapshot dates.** `python -m preloop.cra measure` (preloop 0.17.1, PyPI wheel) produced the minimum-elements measurement. OSV.dev was queried at `2026-11-04T02:14:26Z`; the KEV snapshot is `2026-11-03T20:00:24.8741Z`; EPSS was queried at `2026-11-04T02:20:04Z`. NVD was used for 9 requests only (one CPE control, eight CVSS v4 cross-checks), spaced at least seven seconds apart. All CVSS numbers come from OSV vectors via the `cvss` 3.6 calculator; no score was taken from NVD or inferred from a severity label.

## 2. Checks and outcomes

| Check | Result | Evidence |
|---|---|---|
| inputs_payload | PASS | No trigger payload was rendered: the prompt contains the literal placeholder {{trigger_event.payload}}. No gate policy, waivers, project_path, product_provenance, repository_url or previous result was delivered. Default gate policy applied. |
| sbom_format_valid | PASS | 3/3 CycloneDX 1.6 documents validated against the official bom-1.6.schema.json (draft-07) with jsonschema 4.26.0: 0 schema errors, 0 duplicate bom-refs, 0 dangling dependency refs. |
| minimum_elements | PASS | python -m preloop.cra measure (preloop 0.17.1): 576 components across 3 documents; all seven NTIA/CRA elements present; missing []. supplier, name, version, unique identifier and relationships present for every component; document author and timestamp present in every document. |
| relationships_per_format | PASS | Relationships present in all three CycloneDX documents (backend 179, frontend 377, cli 23 dependency entries). No SPDX document was audited, so no per-format contrast applies. |
| coverage_quality | FAIL | 576/576 components carry a version and a purl (100%). 572/576 carry a license declaration (99.3%); 4 components carry no license at all; 0 NOASSERTION values. CycloneDX has no concluded-license field, so concluded = 0%. |
| db_resolvable_coverage | PASS | 576/576 components are db-resolvable by purl (pypi 178, npm 376, golang 22); 0 not db-resolvable. No pkg:generic or pkg:github components were delivered. |
| build_cross_check | SKIPPED | build/SHA256SUMS lists 17 release artifacts, not a component/package manifest. SBOM/VEX digests match: backend, frontend and cli SBOMs and the OpenVEX file all match their SHA256SUMS entries. No component-level build list existed to diff against the SBOM. |
| cross_format_differences | SKIPPED | Only one format (CycloneDX 1.6) was delivered for each sub-product; no cross-format normalization was required or performed. |
| osv_purl_screen | PASS | 576 components queried one per query object as purl-without-qualifiers; 13 components returned 39 advisory ids. Class controls passed for pypi (django 2.0.0, 35 advisories), npm (lodash 4.17.20, 4) and golang (gin v1.6.0, 5). |
| osv_git_screen | PASS | 333 components carried a vcs_url; 251 resolved to a 40-hex upstream commit by tag and were queried with {"commit":...}. 82 had no matching tag and stayed blind for this source; 243 had no vcs_url. Control commit 6fa1d817e5b1a00d7d0c8168091877476b499317 returned CVE-2023-38545. 9 commits returned 40 unique advisory ids. |
| upstream_resolution | PASS | 243 components without vcs_url were batched once to resolve_sbom_upstreams (Arduino index and PlatformIO registry both ok); 0 resolved, 243 unresolved with per-component reasons. No resolution was fabricated. |
| nvd_cpe_control | PASS | Labeled-heuristic control cpe:2.3:a:haxx:curl:7.50.0 returned 77 CVEs. No inventory component is a well-known C library, so this heuristic was not applied to the inventory (0 components screened). |
| osv_distro_control | PASS | Labeled-heuristic control {"package":{"name":"curl"},"version":"7.50.0"} returned 1,711 distro-prefixed advisories. Not applied to registry-versioned inventory components (0 components screened). |
| negative_controls | PASS | All four source controls returned known-vulnerable results; no source was blind. Control results were not quarantined. |
| kev_fetch | PASS | CISA KEV fetched from the cisa.gov primary URL: catalogVersion 2026.11.03, dateReleased 2026-11-03T20:00:24.8741Z, 1,767 entries. Zero of the 71 findings (or their aliases) are KEV-listed. |
| epss_fetch | PASS | EPSS v1 queried for 69 CVE ids; 62 scored entries returned; 7 CVEs had no EPSS row and are null. |
| vex_application | PASS | OpenVEX document https://preloop.ai/vex/preloop-frontend-0.16.0-1 (25 statements) applied before the gate. 25 findings matched a statement with not_affected plus a non-empty justification and were suppressed; 0 of them would have failed the gate (all CVSS below 9.0, none KEV). VEX suppressed 24 undici-types git-range findings and 1 lodash.camelcase finding. |
| severity_gate | FAIL | After VEX subtraction and waiver application, 2 database findings fail the default policy: GHSA-6v38-4h7w-rj9h (Authlib 1.8.0, CVSS 9.1) and GHSA-7hp6-4w63-5g45 (litellm 1.101.0, CVSS 9.9). No waiver input existed. Gate failed. |
| waivers | SKIPPED | No waiver file, inline waivers, or interactive waiver collection flag was delivered; run was non-interactive. No ask_user call was made. |
| drift | SKIPPED | No previous result.json was delivered; drift is null and no baseline was guessed. |
| gap_register | SKIPPED | gap_register: skipped — no repository attached. No git checkout under /workspace and no repository_url in the payload. |
| evidence_storage | SKIPPED | evidence_storage: skipped — no repositories attached. Artifact-only audit; no stubs or product pack were written to a checkout. |
| project_scope | SKIPPED | No project_path was delivered; the artifact set (all three SBOMs) is the unit of audit and scope is null. |
| sbom_artifact_hashes | PASS | sha256 of backend/frontend/cli SBOMs and preloop-frontend.openvex.json match the corresponding entries in build/SHA256SUMS. |

## 3. Findings

**71 findings:** 2 critical, 24 high, 38 medium, 7 low, 0 unknown. All are database-source matches (OSV purl and/or OSV git ranges); no heuristic-only findings were produced. Counts are the length of the final findings list.

| Sev | Finding | CVE | Package | CVSS | Source | VEX | Fixed in |
|---|---|---|---|---|---|---|---|
| **critical** | GHSA-6v38-4h7w-rj9h | CVE-2026-96760 | Authlib 1.8.0 | 9.1 | osv_purl | — | 1.9.0 |
| **critical** | GHSA-7hp6-4w63-5g45 | CVE-2026-114612 | litellm 1.101.0 | 9.9 | osv_purl | — | 1.101.3 |
| high | GHSA-7vr2-2fgp-9w7p | CVE-2026-114615 | Authlib 1.8.0 | 7.4 | osv_purl | — | 1.9.0 |
| high | GHSA-8m4g-j4wp-wgcg | CVE-2026-114616 | Authlib 1.8.0 | 7.4 | osv_purl | — | 1.9.1 |
| high | GHSA-c73q-w75p-j82v | CVE-2026-116672 | Authlib 1.8.0 | 8.8 | osv_purl | — | 1.9.1 |
| high | GHSA-ch7m-m9rf-8gvv | CVE-2025-59162 | color-convert 2.0.1 | 8.8 | osv_git | — | — |
| high | GHSA-45c3-73f7-pv4m | CVE-2026-114605 | dnspython 2.8.0 | 7.5 | osv_purl | — | 2.9.0 |
| high | GHSA-v4x8-3wr5-3wq8 | CVE-2026-112940 | filelock 3.32.5 | 7.1 | osv_purl | — | 4.2.1 |
| high | CVE-2026-109380 | CVE-2026-109380 | modern-tar 0.8.5 | 8.7 | osv_git | — | — |
| high | GHSA-j586-36cw-2gc2 | CVE-2026-114613 | msgpack 1.2.2 | 7.5 | osv_purl | — | 1.2.3 |
| high | GHSA-q978-78c7-phqw | CVE-2026-119025 | open 8.4.2 | 7.7 | osv_git | — | — |
| high | CVE-2026-112366 | CVE-2026-112366 | picomatch 4.0.4 | 8.7 | osv_git | — | — |
| high | GHSA-2qm8-x737-gmw5 | CVE-2026-119196 | pyasn1 0.6.4 | 7.5 | osv_purl | — | 0.6.5 |
| high | GHSA-9m75-vc3g-4x39 | CVE-2026-119195 | pyasn1 0.6.4 | 7.5 | osv_purl | — | 0.6.5 |
| high | GHSA-fm9c-5rcf-2q5p | CVE-2026-119194 | pyasn1 0.6.4 | 7.5 | osv_purl | — | 0.6.5 |
| high | GHSA-mm57-4v3p-rchx | CVE-2026-119197 | pyasn1 0.6.4 | 7.5 | osv_purl | — | 0.6.5 |
| high | GHSA-2m5v-pch6-74hx | CVE-2026-109383 | undici-types 7.16.0 | 7.4 | osv_git | — | — |
| high | GHSA-4cwx-7wf7-3272 | CVE-2026-13697 | undici-types 7.16.0 | 7.4 | osv_git | suppressed: not_affected | — |
| high | GHSA-4w7w-5xrc-9h26 | CVE-2026-109829 | undici-types 7.16.0 | 7.4 | osv_git | — | — |
| high | GHSA-f269-vfmq-vjvj | CVE-2026-1528 | undici-types 7.16.0 | 7.5 | osv_git | suppressed: not_affected | — |
| high | GHSA-qrxm-fqhp-jwvm | CVE-2026-87018 | undici-types 7.16.0 | 7.5 | osv_git | — | — |
| high | GHSA-rfgv-xxqx-mfg5 | CVE-2026-19534 | undici-types 7.16.0 | 7.5 | osv_git | suppressed: not_affected | — |
| high | GHSA-v9p9-hfj2-hcw8 | CVE-2026-2229 | undici-types 7.16.0 | 7.5 | osv_git | suppressed: not_affected | — |
| high | GHSA-vrm6-8vpv-qv8q | CVE-2026-1526 | undici-types 7.16.0 | 7.5 | osv_git | suppressed: not_affected | — |
| high | GHSA-vxpw-j846-p89q | CVE-2026-12151 | undici-types 7.16.0 | 7.5 | osv_git | suppressed: not_affected | — |
| high | GHSA-mrhx-c7xc-m3w5 | CVE-2023-54404 | zod 3.25.76 | 7.5 | osv_git, osv_purl | — | 4.6.6 |
| medium | GHSA-c5mf-xmp2-59rc | CVE-2026-114617 | Authlib 1.8.0 | 4.2 | osv_purl | — | 1.9.0 |
| medium | GHSA-fch4-3c6x-j4gc | CVE-2026-114618 | Authlib 1.8.0 | 6.8 | osv_purl | — | 1.9.0 |
| medium | GHSA-q686-2qmg-hqc7 | CVE-2026-114619 | Authlib 1.8.0 | 4.6 | osv_purl | — | 1.9.0 |
| medium | GHSA-x4rv-c3wx-4cr8 | CVE-2026-114620 | Authlib 1.8.0 | 5.4 | osv_purl | — | 1.9.0 |
| medium | GHSA-gcqx-w48m-w2h4 | CVE-2026-93753 | deepmerge 4.3.1 | 5.3 | osv_git, osv_purl | — | — |
| medium | GHSA-7xgj-8392-5q4r | — | fastmcp 3.4.7 | 6.8 | osv_purl | — | 3.4.10 |
| medium | GHSA-7xgj-8392-5q4r | — | fastmcp-slim 3.4.7 | 6.8 | osv_purl | — | 3.4.10 |
| medium | GHSA-6627-m3xw-93mp | CVE-2026-112908 | filelock 3.32.5 | 5.3 | osv_purl | — | 4.2.1 |
| medium | GHSA-69hj-f68j-2879 | CVE-2026-112909 | filelock 3.32.5 | 6.1 | osv_purl | — | 4.2.1 |
| medium | GHSA-8mx5-7m5m-r77g | CVE-2026-112910 | filelock 3.32.5 | 5.3 | osv_purl | — | 4.2.1 |
| medium | GHSA-9c4x-gm8v-wgc4 | CVE-2026-112911 | filelock 3.32.5 | 6.3 | osv_purl | — | 4.2.1 |
| medium | GHSA-cwqr-hh33-gh44 | CVE-2026-112915 | filelock 3.32.5 | 5.5 | osv_purl | — | 4.2.1 |
| medium | GHSA-fq56-3cx3-fjxp | CVE-2026-112935 | filelock 3.32.5 | 4.7 | osv_purl | — | 4.2.1 |
| medium | GHSA-j8f7-rjxc-mr56 | CVE-2026-112936 | filelock 3.32.5 | 6.1 | osv_purl | — | 4.0.9 |
| medium | GHSA-m462-7rxw-wvpg | CVE-2026-112938 | filelock 3.32.5 | 5.8 | osv_purl | — | 4.2.1 |
| medium | GHSA-rfpc-qcw5-3pc4 | CVE-2026-112939 | filelock 3.32.5 | 4.7 | osv_purl | — | 4.2.1 |
| medium | GHSA-9pg5-8c7x-5hfx | CVE-2026-119284 | joserfc 1.7.5 | 6.9 | osv_purl | — | 1.7.6 |
| medium | GHSA-fvqr-27wr-82fm | CVE-2018-3721 | lodash.camelcase 4.3.0 | 6.5 | osv_git | suppressed: not_affected | — |
| medium | GHSA-xcq7-p3pf-p88h | CVE-2026-114603 | opentelemetry-api 1.44.0 | 5.3 | osv_purl | — | 1.45.1 |
| medium | GHSA-6pq8-jhm2-2vcw | CVE-2026-110816 | qs 6.16.0 | 5.3 | osv_git, osv_purl | — | 6.16.1 |
| medium | GHSA-w4cr-vjpx-p82q | CVE-2026-110910 | qs 6.16.0 | 6.3 | osv_git | — | — |
| medium | GHSA-2jfj-6hjv-fm6j | CVE-2026-84933 | undici-types 7.16.0 | 6.5 | osv_git | suppressed: not_affected | — |
| medium | GHSA-2mjp-6q6p-2qxm | CVE-2026-1525 | undici-types 7.16.0 | 6.5 | osv_git | suppressed: not_affected | — |
| medium | GHSA-3xpg-4rpp-hhhm | CVE-2026-84890 | undici-types 7.16.0 | 5.9 | osv_git | suppressed: not_affected | — |
| medium | GHSA-4992-7rv2-5pvq | CVE-2026-1527 | undici-types 7.16.0 | 4.6 | osv_git | suppressed: not_affected | — |
| medium | GHSA-4qv8-2p9j-2685 | CVE-2026-109924 | undici-types 7.16.0 | 5.9 | osv_git | — | — |
| medium | GHSA-55wc-3pg8-jfw6 | CVE-2026-87029 | undici-types 7.16.0 | 5.9 | osv_git | — | — |
| medium | GHSA-8xcm-r25x-g524 | CVE-2026-16728 | undici-types 7.16.0 | 4.8 | osv_git | suppressed: not_affected | — |
| medium | GHSA-9fm3-97px-rjf6 | CVE-2026-109932 | undici-types 7.16.0 | 5.9 | osv_git | — | — |
| medium | GHSA-f72v-6w45-q472 | CVE-2026-109841 | undici-types 7.16.0 | 5.9 | osv_git | — | — |
| medium | GHSA-g9mf-h72j-4rw9 | CVE-2026-22036 | undici-types 7.16.0 | 5.9 | osv_git | suppressed: not_affected | — |
| medium | GHSA-jr45-8vmc-qm54 | CVE-2026-14643 | undici-types 7.16.0 | 5.9 | osv_git | suppressed: not_affected | — |
| medium | GHSA-m8rv-5g2x-5cg5 | CVE-2026-15157 | undici-types 7.16.0 | 4.2 | osv_git | suppressed: not_affected | — |
| medium | GHSA-p88m-4jfj-68fv | CVE-2026-9679 | undici-types 7.16.0 | 5.9 | osv_git | suppressed: not_affected | — |
| medium | GHSA-pmjh-fq2x-6v4x | CVE-2026-18149 | undici-types 7.16.0 | 5.9 | osv_git | suppressed: not_affected | — |
| medium | GHSA-pr7r-676h-xcf6 | CVE-2026-9678 | undici-types 7.16.0 | 5.9 | osv_git | suppressed: not_affected | — |
| medium | GHSA-rx4f-c7p8-82vq | CVE-2026-85014 | undici-types 7.16.0 | 5.9 | osv_git | suppressed: not_affected | — |
| medium | GHSA-v3r7-h72x-cjcm | CVE-2026-16729 | undici-types 7.16.0 | 4.8 | osv_git | suppressed: not_affected | — |
| low | GHSA-567q-5qvw-pf92 | CVE-2026-112907 | filelock 3.32.5 | 2.5 | osv_purl | — | 4.2.1 |
| low | GHSA-9vhv-jxww-xfm5 | CVE-2026-112913 | filelock 3.32.5 | 3.3 | osv_purl | — | 4.2.1 |
| low | GHSA-2gqq-gqf2-x968 | CVE-2026-84947 | undici-types 7.16.0 | 3.7 | osv_git | suppressed: not_affected | — |
| low | GHSA-35p6-xmwp-9g52 | CVE-2026-6733 | undici-types 7.16.0 | 3.7 | osv_git | suppressed: not_affected | — |
| low | GHSA-8436-99hf-9mmv | CVE-2026-85008 | undici-types 7.16.0 | 3.7 | osv_git | suppressed: not_affected | — |
| low | GHSA-g8m3-5g58-fq7m | CVE-2026-11525 | undici-types 7.16.0 | 3.7 | osv_git | suppressed: not_affected | — |
| low | GHSA-r53p-7pc4-xj5r | CVE-2026-18540 | undici-types 7.16.0 | 3.7 | osv_git | suppressed: not_affected | — |

**KEV hits:** none. No finding, or any of its aliases, appears in the 2026.11.03 KEV catalogue. The catalogue does list three *other* LiteLLM CVEs (CVE-2026-59822, CVE-2026-42271, CVE-2026-42208) that OSV does not associate with litellm 1.101.0; they are not findings on this evidence, but a human should confirm whether the shipped version is in scope for them.

**Reading the high/medium tail.** Several findings come from OSV GIT ranges reached through npm `vcs_url` metadata rather than from the npm version range: `color-convert 2.0.1` (advisory describes malware in 3.1.1), `lodash.camelcase 4.3.0` (CVE-2018-3721 through the lodash repository tag) and the `undici-types` family (advisories against the undici runtime). They are reported as database matches because that is what the source returned, but they warrant human review before remediation tickets are filed. The VEX suppresses the named undici-types and lodash.camelcase ones.

## 4. Gate outcome

**Policy:** fail_on_kev=true; fail_on_cvss_gte=9.0; fail_on_unscored=true (platform defaults; no payload policy delivered).

**Result: FAIL.** Passed before waivers: `false`. Passed after waivers: `false`. Unwaived failures: `GHSA-6v38-4h7w-rj9h, GHSA-7hp6-4w63-5g45` — Authlib 1.8.0 GHSA-6v38-4h7w-rj9h (CVSS 9.1) and litellm 1.101.0 GHSA-7hp6-4w63-5g45 (CVSS 9.9). No waivers were delivered, so waiver application changed nothing. VEX-suppressed findings are excluded from this population; none of them would have failed.

The gap-register rule — gap items appear as failed checks, can move a clean run to `pass_with_findings`, but can never flip the severity gate or the SBOM-audit verdict — does not affect this result: no gap register ran, and the gate failed on its own evidence.

## 5. What this run does not establish

- It does not establish that the 325 components not screened by `osv_git` are free of git-range advisories. They were screened by `osv_purl`, which supports an absence claim only for the purl source.
- It does not establish that the 576 components not screened by `nvd_cpe` or `osv_distro` are clean under those heuristics; those sources were controls only, not inventory screens.
- It does not establish SBOM completeness against the build: no component/package build manifest was delivered.
- It does not establish any CRA gap-register item: no repository was attached.
- It does not establish that the VEX `not_affected` claims are technically correct; it applies the supplier’s statements as delivered.

## 6. Method notes and limitations

- **Inventory of record.** The three delivered SBOMs, 576 components total (178 pypi, 376 npm, 22 golang). The SBOM was not regenerated or reconstructed. Root product components are excluded from the component denominator, matching `preloop.cra measure`.
- **purl screening.** One component per query object, qualifiers stripped, for every component. 13 components returned 39 advisory ids; after alias grouping (GHSA/PYSEC/CVE) they became the purl-source findings in the register.
- **git-range screening.** 333 components carry `vcs_url`; 251 resolved to a 40-hex commit by matching the component version to an upstream tag (`git ls-remote --tags`, read-only) and were queried with `{"commit": ...}`. 9 commits returned 40 unique advisory ids. 82 components had a `vcs_url` but no tag matching the component version and stayed blind for this source; 243 had no `vcs_url` and were batched once to `resolve_sbom_upstreams`, which resolved none.
- **VEX application.** Applied before the gate. A finding is suppressed only when status is `not_affected`/`fixed`/`false_positive` **and** a non-empty justification is present. All 25 matched statements met both conditions. Findings outside the statement’s product purl or vulnerability id were not suppressed.
- **Scoring.** CVSS v3.1 where OSV supplied a V3 vector, otherwise CVSS v4.0 base score from the supplied V4 vector. No score was fabricated, derived from a severity label, or copied from EPSS. No finding is unscored.
- **Absence claims are per source.** `screened_by_no_source` is 0 only because `osv_purl` screened all 576; it does not mean all four sources covered everything.

## 7. Artefacts

- `evidence/audit-report.md` — this report.
- `evidence/findings.json` — full machine-readable finding register (71 entries).
- `evidence/source-matrix.json` — component × source matrix for all 576 components, with controls.
- `evidence/sbom-findings.json` — SBOM verification register, schema results, coverage and licence detail.
- `evidence/waivers.json` — not created: no waiver input existed and the run was non-interactive.
- `evidence/gap-register.md` — not created: no repository attached.
- `evidence/drift-report.md` — not created: no previous result delivered.

Machine-generated evidence for conformity assessment support. Not a conformity assessment, certification, or legal advice.
